main() {
    int a, b, c;
    a = 1;
    b = 3;
    c = 4;

    a = a + b;
    c = a - b;
    b = b * b;
}