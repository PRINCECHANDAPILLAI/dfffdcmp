// Program to calculate the sum of two numbers

#include <stdio.h>
#include <string.h>
#include <ctype.h>

void main() {

    /* This is a
       multiline comment */

    int num1, num2, sum;
    float num3 = 5.5;

    num1 = 10;
    num2 = 20;

    sum = num1 + num2;
}
