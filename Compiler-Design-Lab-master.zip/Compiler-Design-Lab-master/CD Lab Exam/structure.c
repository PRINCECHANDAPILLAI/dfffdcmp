struct LabExamination {
    int rollNo;
    char* name;
    float labMarks, continuousEvaluation, totalMarks;
};